# DuoArt — landing page

Site estático responsivo, pronto para GitHub e Vercel, sem dependências de Node.js e sem processo de compilação.

## Estrutura

```text
duoart-site/
├── index.html                  # Página principal
├── assets/
│   ├── logo-duoart.png         # Logo extraída da referência da marca
│   ├── favicon.png             # Ícone da aba
│   ├── imas-personalizados.webp
│   ├── ima-familia.webp
│   ├── ima-crianca.webp
│   ├── ima-cachorro.webp
│   └── ima-pet.webp
├── css/styles.css              # Estilo e animação do carrossel
├── js/main.js                  # Botões de quantidade e WhatsApp
└── README.md
```

## Publicar no GitHub + Vercel

1. Crie um repositório vazio no GitHub, por exemplo `duoart-site`.
2. Clique em **Add file → Upload files**, e envie **o conteúdo desta pasta** (`index.html`, `assets/`, `css/`, `js/` e `README.md`). O `index.html` precisa ficar na **raiz** do repositório.
3. Confirme em **Commit changes**.
4. Na Vercel, clique em **Add New → Project**, selecione o repositório do GitHub e importe.
5. Configure **Framework Preset: Other**. Não precisa de `npm install` nem de **Build Command**. Deixe **Output Directory** no padrão/sem valor e **Root Directory** na raiz do projeto.
6. Clique em **Deploy**. A Vercel entregará uma URL terminada em `vercel.app`; depois você pode adicionar um domínio personalizado.

## Alterações simples

- **Número do WhatsApp:** em `js/main.js`, altere a constante `WHATSAPP_NUMBER` (formato internacional, sem espaço, ex.: `5521...`). Para o fallback sem JavaScript, altere também os três links `wa.me` de `index.html` (`order-link`, `event-link` e `sticky-link`). O telefone não é exibido visualmente, mas o link é público no código-fonte.
- **Instagram:** altere os dois links para `instagram.com/duoart_l/` no `index.html`.
- **Quantidade e textos:** no `index.html`; a mensagem enviada ao WhatsApp está em `js/main.js`.
- **Fotos:** substitua as imagens em `assets/` mantendo os mesmos nomes e formatos. Nenhuma imagem depende de link externo.
- **Cores/visual:** edite `css/styles.css` (variáveis em `:root`).

## Atenção às fotografias

As imagens atuais são **composições ilustrativas geradas digitalmente**, não fotografias de pedidos reais da DuoArt. Antes de apresentá-las como produtos fabricados, substitua por fotos próprias/autorizadas, preservando o formato quadrado.

A fonte principal usa Google Fonts quando disponível e possui alternativas locais (`Georgia` e sans-serif) em caso de bloqueio da conexão.
