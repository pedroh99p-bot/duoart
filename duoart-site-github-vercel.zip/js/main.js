// DuoArt — links de contato e seleção de quantidade
// O número fica no código do link, mas não é mostrado visualmente no site.
const WHATSAPP_NUMBER = '5521979167636';

function whatsAppLink(message) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

let selectedQuantity = '5';

function personalMessage() {
  const unit = selectedQuantity === '1' ? 'ímã quadrado personalizado' : 'ímãs quadrados personalizados';
  return `Olá, DuoArt! Quero solicitar um orçamento de ${selectedQuantity} ${unit}. Como posso enviar minhas fotos?`;
}

function updatePersonalQuote() {
  const link = whatsAppLink(personalMessage());
  document.querySelector('#order-link').href = link;
  document.querySelector('#sticky-link').href = link;

  const amount = Number(selectedQuantity).toLocaleString('pt-BR');
  const selected = document.querySelector('#selected');
  selected.innerHTML = `${selectedQuantity === '1' ? '' : 'Kit com '}<strong>${amount} ${selectedQuantity === '1' ? 'ímã' : 'ímãs'}</strong> selecionado`;

  document.querySelectorAll('.qty').forEach((button) => {
    const active = button.dataset.q === selectedQuantity;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

document.querySelectorAll('.qty').forEach((button) => {
  button.addEventListener('click', () => {
    selectedQuantity = button.dataset.q;
    updatePersonalQuote();
  });
});

let eventQuantity = '50';

function updateEventQuote() {
  document.querySelector('#event-link').href = whatsAppLink(
    `Olá, DuoArt! Quero solicitar um orçamento para ${eventQuantity} ímãs fotográficos quadrados para um evento ou empresa.`
  );
  document.querySelectorAll('.event-qty').forEach((button) => {
    const active = button.dataset.n === eventQuantity;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

document.querySelectorAll('.event-qty').forEach((button) => {
  button.addEventListener('click', () => {
    eventQuantity = button.dataset.n;
    updateEventQuote();
  });
});

updatePersonalQuote();
updateEventQuote();
